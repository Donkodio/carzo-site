const MARKETPLACES = {
  mobile_de: {
    label: 'Mobile.de',
    loginUrl: 'https://www.mobile.de/login',
    domains: ['mobile.de', '.mobile.de', 'suchen.mobile.de'],
    urlMatch: ['mobile.de'],
  },
  kleinanzeigen: {
    label: 'Kleinanzeigen',
    loginUrl: 'https://www.kleinanzeigen.de/einloggen',
    domains: ['kleinanzeigen.de', '.kleinanzeigen.de'],
    urlMatch: ['kleinanzeigen.de'],
  },
  olx_pl: {
    label: 'OLX.pl',
    loginUrl: 'https://www.olx.pl/account/login/',
    domains: ['olx.pl', '.olx.pl', 'login.olx.pl'],
    urlMatch: ['olx.pl'],
  },
  autoscout24: {
    label: 'AutoScout24',
    loginUrl: 'https://www.autoscout24.com/account/login',
    domains: ['autoscout24.com', '.autoscout24.com', 'autoscout24.de', '.autoscout24.de'],
    urlMatch: ['autoscout24.com', 'autoscout24.de'],
  },
  otomoto: {
    label: 'Otomoto.pl',
    loginUrl: 'https://www.otomoto.pl/konto/logowanie',
    domains: ['otomoto.pl', '.otomoto.pl', 'login.otomoto.pl', '.login.otomoto.pl'],
    urlMatch: ['otomoto.pl'],
  },
  sauto_cz: {
    label: 'Sauto.cz',
    loginUrl: 'https://www.sauto.cz/prihlaseni',
    domains: ['sauto.cz', '.sauto.cz', 'seznam.cz', '.seznam.cz'],
    urlMatch: ['sauto.cz', 'seznam.cz'],
  },
  autovit_ro: {
    label: 'Autovit.ro',
    loginUrl: 'https://www.autovit.ro/cont/login',
    domains: ['autovit.ro', '.autovit.ro', 'login.autovit.ro', '.login.autovit.ro'],
    urlMatch: ['autovit.ro'],
  },
  autotrack_nl: {
    label: 'AutoTrack.nl',
    loginUrl: 'https://www.autotrack.nl/inloggen',
    domains: ['autotrack.nl', '.autotrack.nl'],
    urlMatch: ['autotrack.nl'],
  },
  autotrack_be: {
    label: 'AutoTrack.be',
    loginUrl: 'https://www.autotrack.be/inloggen',
    domains: ['autotrack.be', '.autotrack.be'],
    urlMatch: ['autotrack.be'],
  },
  marktplaats_nl: {
    label: 'Marktplaats.nl',
    loginUrl: 'https://www.marktplaats.nl/account/login.html',
    domains: ['marktplaats.nl', '.marktplaats.nl'],
    urlMatch: ['marktplaats.nl'],
  },
  '2dehands_be': {
    label: '2dehands.be',
    loginUrl: 'https://www.2dehands.be/account/login.html',
    domains: ['2dehands.be', '.2dehands.be', '2ememain.be', '.2ememain.be'],
    urlMatch: ['2dehands.be', '2ememain.be'],
  },
};

const DEFAULT_API = 'https://carzo.site/api';
const MAX_SYNC_COOKIES = 80;
const MAX_COOKIE_VALUE_LENGTH = 8192;
const NOISE_COOKIE_RE = /consent|gdpr|cookie|privacy|banner|analytics|tracking|optanon|euconsent|_ga|_gid|_gat|cf_|ak_bmsc|bm_sv|bm_sz|_abck|hj|hotjar|fpg|fpid|fpau|fplc|fbp|gtm|gcl|visitor|cmp|culture|disable|kameleoon|asse|dd_|datadome/i;

function cleanApiUrl(url) {
  return String(url || DEFAULT_API).trim().replace(/\/+$/, '');
}

function normalizeCookie(cookie) {
  return {
    name: cookie.name,
    value: cookie.value,
    domain: cookie.domain,
    path: cookie.path || '/',
    expires: typeof cookie.expirationDate === 'number' ? cookie.expirationDate : undefined,
    httpOnly: Boolean(cookie.httpOnly),
    secure: Boolean(cookie.secure),
    sameSite: cookie.sameSite || undefined,
  };
}

function cookieDomainMatches(cookie, config) {
  const domain = String(cookie.domain || '').replace(/^\./, '').toLowerCase();
  if (!domain) return false;
  return config.domains.some((allowed) => {
    const normalized = String(allowed).replace(/^\./, '').toLowerCase();
    return domain === normalized || domain.endsWith(`.${normalized}`);
  });
}

function isAuthLikeCookie(cookie) {
  const name = String(cookie.name || '').toLowerCase();
  if (!name) return false;
  if (NOISE_COOKIE_RE.test(name)) {
    return false;
  }
  if (/auth|login|logged|account|identity|token|jwt|remember|oauth|refresh|access|secure|ticket|sso/.test(name)) {
    return true;
  }
  return (/^(sid|sessid|session|sessionid|jsessionid)$|session[_-]?id/.test(name))
    && cookie.httpOnly === true
    && cookie.secure === true;
}

function isUsefulSyncCookie(cookie) {
  const valueLength = String(cookie.value || '').length;
  if (valueLength === 0 || valueLength > MAX_COOKIE_VALUE_LENGTH) return false;
  if (isAuthLikeCookie(cookie)) return true;
  return !NOISE_COOKIE_RE.test(String(cookie.name || ''));
}

function dedupeCookies(cookies) {
  const map = new Map();
  for (const cookie of cookies) {
    map.set(`${cookie.name}|${cookie.domain}|${cookie.path}`, cookie);
  }
  return [...map.values()];
}

async function collectCookies(config) {
  const all = [];
  for (const domain of config.domains) {
    const cookies = await chrome.cookies.getAll({ domain });
    all.push(...cookies.map(normalizeCookie));
  }
  return dedupeCookies(all);
}

function compactCookiesForSync(cookies, config) {
  const relevant = cookies
    .filter((cookie) => cookieDomainMatches(cookie, config))
    .filter(isUsefulSyncCookie);

  return dedupeCookies(relevant)
    .sort((left, right) => {
      const leftAuth = isAuthLikeCookie(left) ? 0 : 1;
      const rightAuth = isAuthLikeCookie(right) ? 0 : 1;
      if (leftAuth !== rightAuth) return leftAuth - rightAuth;
      return String(left.name || '').localeCompare(String(right.name || ''));
    })
    .slice(0, MAX_SYNC_COOKIES);
}

async function postJson(url, body) {
  const res = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });
  const text = await res.text();
  let data;
  try { data = text ? JSON.parse(text) : {}; } catch { data = { message: text }; }
  if (!res.ok) {
    const message = Array.isArray(data.message) ? data.message.join(', ') : (data.message || data.error || `HTTP ${res.status}`);
    throw new Error(message);
  }
  return data;
}

function getMarketplace(marketplace) {
  const config = MARKETPLACES[marketplace];
  if (!config) throw new Error(`Unsupported marketplace: ${marketplace}`);
  return config;
}

async function heartbeat({ serverUrl, connectorToken, deviceName }) {
  if (!String(connectorToken || '').startsWith('carzo_dc_')) {
    throw new Error('Invalid connector token');
  }
  const api = cleanApiUrl(serverUrl);
  await chrome.storage.local.set({ serverUrl: api, connectorToken });
  return postJson(`${api}/device-connectors/heartbeat`, {
    connectorToken,
    deviceName: deviceName || 'Carzo Browser Connector',
    capabilities: ['platform_session_capture', 'cookies', 'local_storage', 'external_bridge'],
  });
}

async function openLogin({ marketplace, serverUrl, connectorToken }) {
  const config = getMarketplace(marketplace);
  if (connectorToken) {
    await chrome.storage.local.set({ serverUrl: cleanApiUrl(serverUrl), connectorToken, marketplace });
  }
  const tab = await chrome.tabs.create({ url: config.loginUrl, active: true });
  await chrome.storage.local.set({ marketplace, marketplaceTabId: tab.id });
  return { ok: true, tabId: tab.id, loginUrl: config.loginUrl, label: config.label };
}

async function capture({ marketplace, serverUrl, connectorToken }) {
  const config = getMarketplace(marketplace);
  const state = await chrome.storage.local.get(['serverUrl', 'connectorToken', 'marketplaceTabId']);
  const api = cleanApiUrl(serverUrl || state.serverUrl);
  const token = String(connectorToken || state.connectorToken || '');
  if (!token.startsWith('carzo_dc_')) throw new Error('Invalid connector token');

  const rawCookies = await collectCookies(config);
  const cookies = compactCookiesForSync(rawCookies, config);
  const marketplaceCookies = cookies.filter((cookie) => cookieDomainMatches(cookie, config));
  const authCookies = marketplaceCookies.filter(isAuthLikeCookie);
  if (!marketplaceCookies.length) throw new Error(`No ${config.label} cookies found. Open the platform, finish login, then sync again.`);
  if (!authCookies.length) throw new Error(`Only technical ${config.label} cookies found. Login/session cookies are not visible yet.`);

  const browserState = JSON.stringify({
    source: 'carzo-browser-extension-background',
    payloadVersion: 2,
    capturedAt: new Date().toISOString(),
    marketplace,
    cookieCount: cookies.length,
    rawCookieCount: rawCookies.length,
    authCookieNames: authCookies.map((cookie) => cookie.name).slice(0, 30),
  });

  const result = await postJson(`${api}/device-connectors/platform-sessions/${marketplace}/complete`, {
    connectorToken: token,
    cookies,
    browserState,
    userAgent: navigator.userAgent,
    platformUsername: config.label,
  });

  return { ok: true, marketplace, label: config.label, status: result.session?.status || 'connected' };
}

chrome.runtime.onMessageExternal.addListener((message, sender, sendResponse) => {
  const origin = sender?.origin || sender?.url || '';
  if (!/^https:\/\/(www\.)?carzo\.site\b/.test(origin)) {
    sendResponse({ ok: false, error: 'Forbidden sender' });
    return false;
  }

  (async () => {
    if (message?.type === 'carzo:heartbeat') return heartbeat(message);
    if (message?.type === 'carzo:openLogin') return openLogin(message);
    if (message?.type === 'carzo:capture') return capture(message);
    throw new Error(`Unknown message type: ${message?.type || 'empty'}`);
  })()
    .then((result) => sendResponse(result))
    .catch((error) => sendResponse({ ok: false, error: String(error?.message || error) }));

  return true;
});
