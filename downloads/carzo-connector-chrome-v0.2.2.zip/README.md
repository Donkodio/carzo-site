# Carzo Connector — Browser Extension MVP

Version: `0.2.2`

This is the browser connector for Carzo marketplace account sync.

## What it does

- Runs in the user's own Chrome/Edge browser.
- Accepts a one-time `carzo_dc_...` token from Carzo settings.
- Lets the user open Mobile.de, Kleinanzeigen, OLX.pl, AutoScout24, Otomoto, Sauto, Autovit, AutoTrack, Marktplaats and 2dehands login pages.
- After the user logs in normally, captures only cookies/session state for the selected marketplace.
- Sends the captured session to `https://carzo.site/api/device-connectors/platform-sessions/:marketplace/complete`.

## What it does not do

- It does not read or send marketplace passwords.
- It does not auto-submit login forms.
- It does not bypass CAPTCHA, anti-bot pages or marketplace security checks.
- It does not send sessions without the user clicking “Synchronize”.

## Install for testing

1. Download and unzip `carzo-connector-chrome-v0.2.2.zip`.
2. Open Chrome/Edge → Extensions → Developer mode.
3. Click “Load unpacked”.
4. Select the unzipped `browser-extension` folder.
5. Do not open `popup.html` from Finder/Downloads as a normal file.
6. Click the Carzo Connector icon in the Chrome/Edge toolbar or in the puzzle/extensions menu.
7. In Carzo settings create a one-time connector code.
8. Paste the code into the extension popup, check connection, log into a marketplace and synchronize.

The dev build has a pinned Chrome extension ID: `lfkchkilcfafnfkjadhnlhnnckdakokj`.
Carzo web uses this ID by default so the site can call the installed extension directly.
If Chrome shows another ID, remove the old unpacked extension and load this updated `browser-extension` folder again.

## User flow

1. Create a one-time code in Carzo → Settings → Device connector.
2. Open the Carzo Connector popup from the browser extension icon.
3. Paste the code into “Одноразовый код из Carzo” and check the connection.
4. Pick the marketplace in the popup and click “Открыть вход”.
5. Log in normally. Google, Apple and Facebook login redirects are expected.
6. After the marketplace shows the logged-in account, return to the popup and click “Синхронизировать”.

If the popup says it only sees technical cookies, the marketplace login is not finished yet or the browser has not returned from Google/Apple/Facebook to the marketplace domain.

Version `0.2.2` sends a compact session payload: marketplace cookies are sent once, obvious analytics/consent cookies are excluded, and localStorage/sessionStorage values are never sent to Carzo.

If the popup says it was opened as a file/page, the extension may still be installed, but you opened the wrong thing. Close that tab/window and open Carzo Connector from the browser toolbar extension icon. Only `chrome-extension://.../popup.html` has access to cookies/tabs/storage. `file://.../popup.html` cannot work.

## Production bridge

Version `0.2.0` also includes an `externally_connectable` background bridge for `https://carzo.site/*`.
After the extension is published with a stable extension ID, the Carzo website can open marketplace login tabs and request sync through the installed extension without making the user copy/paste the one-time code in the popup as the primary flow.
