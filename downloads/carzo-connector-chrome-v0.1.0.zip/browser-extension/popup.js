const MARKETPLACES = {
  mobile_de: {
    label: 'Mobile.de',
    loginUrl: 'https://www.mobile.de/login',
    domains: ['mobile.de', '.mobile.de', 'suchen.mobile.de'],
    urlMatch: ['mobile.de']
  },
  kleinanzeigen: {
    label: 'Kleinanzeigen',
    loginUrl: 'https://www.kleinanzeigen.de/einloggen',
    domains: ['kleinanzeigen.de', '.kleinanzeigen.de'],
    urlMatch: ['kleinanzeigen.de']
  },
  olx_pl: {
    label: 'OLX.pl',
    loginUrl: 'https://www.olx.pl/account/login/',
    domains: ['olx.pl', '.olx.pl', 'login.olx.pl'],
    urlMatch: ['olx.pl']
  },
  autoscout24: {
    label: 'AutoScout24',
    loginUrl: 'https://www.autoscout24.com/account/login',
    domains: ['autoscout24.com', '.autoscout24.com', 'autoscout24.de', '.autoscout24.de'],
    urlMatch: ['autoscout24.com', 'autoscout24.de']
  },
  otomoto: {
    label: 'Otomoto.pl',
    loginUrl: 'https://www.otomoto.pl/konto/logowanie',
    domains: ['otomoto.pl', '.otomoto.pl', 'login.otomoto.pl', '.login.otomoto.pl'],
    urlMatch: ['otomoto.pl']
  },
  sauto_cz: {
    label: 'Sauto.cz',
    loginUrl: 'https://www.sauto.cz/prihlaseni',
    domains: ['sauto.cz', '.sauto.cz', 'seznam.cz', '.seznam.cz'],
    urlMatch: ['sauto.cz', 'seznam.cz']
  },
  autovit_ro: {
    label: 'Autovit.ro',
    loginUrl: 'https://www.autovit.ro/cont/login',
    domains: ['autovit.ro', '.autovit.ro', 'login.autovit.ro', '.login.autovit.ro'],
    urlMatch: ['autovit.ro']
  },
  autotrack_nl: {
    label: 'AutoTrack.nl',
    loginUrl: 'https://www.autotrack.nl/inloggen',
    domains: ['autotrack.nl', '.autotrack.nl'],
    urlMatch: ['autotrack.nl']
  },
  autotrack_be: {
    label: 'AutoTrack.be',
    loginUrl: 'https://www.autotrack.be/inloggen',
    domains: ['autotrack.be', '.autotrack.be'],
    urlMatch: ['autotrack.be']
  },
  marktplaats_nl: {
    label: 'Marktplaats.nl',
    loginUrl: 'https://www.marktplaats.nl/account/login.html',
    domains: ['marktplaats.nl', '.marktplaats.nl'],
    urlMatch: ['marktplaats.nl']
  },
  '2dehands_be': {
    label: '2dehands.be',
    loginUrl: 'https://www.2dehands.be/account/login.html',
    domains: ['2dehands.be', '.2dehands.be', '2ememain.be', '.2ememain.be'],
    urlMatch: ['2dehands.be', '2ememain.be']
  }
};

const SOCIAL_LOGIN_HINT = 'Если вы вошли через Google/Apple/Facebook — это нормально. Дождитесь возврата на площадку и нажмите «Синхронизировать» после входа.';

const els = {
  serverUrl: document.getElementById('serverUrl'),
  connectorToken: document.getElementById('connectorToken'),
  marketplace: document.getElementById('marketplace'),
  saveToken: document.getElementById('saveToken'),
  openLogin: document.getElementById('openLogin'),
  capture: document.getElementById('capture'),
  tokenStatus: document.getElementById('tokenStatus'),
  syncStatus: document.getElementById('syncStatus')
};

function setStatus(el, message, tone = 'muted') {
  el.textContent = message;
  el.className = `status ${tone}`;
}

function cleanApiUrl(url) {
  return String(url || 'https://carzo.site/api').trim().replace(/\/+$/, '');
}

function storageGet(keys) {
  return chrome.storage.local.get(keys);
}

function storageSet(payload) {
  return chrome.storage.local.set(payload);
}

function cookiesGetAll(filter) {
  return chrome.cookies.getAll(filter);
}

function tabsQuery(query) {
  return chrome.tabs.query(query);
}

function tabsCreate(payload) {
  return chrome.tabs.create(payload);
}

function executeScript(tabId, func) {
  return chrome.scripting.executeScript({ target: { tabId }, func });
}

function normalizeCookie(cookie) {
  return {
    name: cookie.name,
    value: cookie.value,
    domain: cookie.domain,
    path: cookie.path || '/',
    expires: typeof cookie.expirationDate === 'number' ? cookie.expirationDate : undefined,
    httpOnly: Boolean(cookie.httpOnly),
    secure: Boolean(cookie.secure),
    sameSite: cookie.sameSite || undefined
  };
}

function cookieDomainMatches(cookie, config) {
  const domain = String(cookie.domain || '').replace(/^\./, '').toLowerCase();
  if (!domain) return false;
  return config.domains.some((allowed) => {
    const normalized = String(allowed).replace(/^\./, '').toLowerCase();
    return domain === normalized || domain.endsWith(`.${normalized}`);
  });
}

function isAuthLikeCookie(cookie) {
  const name = String(cookie.name || '').toLowerCase();
  if (!name) return false;

  if (/consent|gdpr|cookie|privacy|banner|analytics|tracking|optanon|euconsent|_ga|_gid|_gat|cf_|ak_bmsc|bm_sv|bm_sz|_abck|hj|hotjar|fpg|fpid|fpau|fplc|fbp|gtm|gcl|visitor|cmp|culture|disable|kameleoon|asse/.test(name)) {
    return false;
  }

  if (/auth|login|logged|account|identity|token|jwt|remember|oauth|refresh|access|secure|ticket|sso/.test(name)) {
    return true;
  }

  return (/^(sid|sessid|session|sessionid|jsessionid)$|session[_-]?id/.test(name))
    && cookie.httpOnly === true
    && cookie.secure === true;
}

function dedupeCookies(cookies) {
  const map = new Map();
  for (const cookie of cookies) {
    const key = `${cookie.name}|${cookie.domain}|${cookie.path}`;
    map.set(key, cookie);
  }
  return [...map.values()];
}

async function collectCookies(config) {
  const all = [];
  for (const domain of config.domains) {
    const cookies = await cookiesGetAll({ domain });
    all.push(...cookies.map(normalizeCookie));
  }
  return dedupeCookies(all);
}

async function collectActiveTabState(config) {
  const [tab] = await tabsQuery({ active: true, currentWindow: true });
  if (!tab?.id || !tab.url || !config.urlMatch.some((part) => tab.url.includes(part))) {
    return { tabUrl: tab?.url, localStorage: {}, sessionStorage: {}, title: tab?.title };
  }

  try {
    const [result] = await executeScript(tab.id, () => {
      const dump = (store) => {
        const out = {};
        for (let i = 0; i < store.length; i += 1) {
          const key = store.key(i);
          if (key) out[key] = store.getItem(key);
        }
        return out;
      };
      return {
        url: location.href,
        title: document.title,
        localStorage: dump(localStorage),
        sessionStorage: dump(sessionStorage)
      };
    });
    return result?.result || { tabUrl: tab.url, localStorage: {}, sessionStorage: {}, title: tab.title };
  } catch (error) {
    return { tabUrl: tab.url, localStorage: {}, sessionStorage: {}, title: tab.title, error: String(error?.message || error) };
  }
}

async function postJson(url, body) {
  const res = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body)
  });
  const text = await res.text();
  let data;
  try { data = text ? JSON.parse(text) : {}; } catch { data = { message: text }; }
  if (!res.ok) {
    const msg = Array.isArray(data.message) ? data.message.join(', ') : (data.message || data.error || `HTTP ${res.status}`);
    throw new Error(msg);
  }
  return data;
}

function humanizeError(error, config) {
  const raw = String(error?.message || error || '').trim();
  if (!raw) return 'Неизвестная ошибка. Проверьте код, вход на площадке и попробуйте ещё раз.';
  if (/failed to fetch|networkerror|load failed/i.test(raw)) {
    return 'Не удалось достучаться до Carzo API. Проверьте интернет, адрес API и что сайт Carzo открыт.';
  }
  if (/invalid device connector token/i.test(raw)) {
    return 'Carzo не узнал одноразовый код. Скопируйте новый код в Carzo → Настройки → Подключение через устройство и вставьте его сюда.';
  }
  if (/token is not active|expired|not active/i.test(raw)) {
    return 'Одноразовый код истёк или устройство отозвано. Создайте новый код в Carzo Settings и вставьте его в расширение.';
  }
  if (/marketplace does not support/i.test(raw)) {
    return `${config?.label || 'Эта площадка'} пока не включена на сервере Carzo. Обновите расширение/страницу Settings или напишите в поддержку.`;
  }
  if (/login is not confirmed|no authenticated marketplace session cookies|no auth\/session-like marketplace cookies/i.test(raw)) {
    return `Carzo получил cookies, но среди них нет login/session cookies ${config?.label || 'площадки'}. ${SOCIAL_LOGIN_HINT}`;
  }
  if (/no marketplace session cookies|no .*session/i.test(raw)) {
    return `Сессия площадки не найдена. Откройте вход через расширение, завершите авторизацию и нажмите «Синхронизировать». ${SOCIAL_LOGIN_HINT}`;
  }
  return raw;
}

async function loadState() {
  const state = await storageGet(['serverUrl', 'connectorToken', 'marketplace']);
  els.serverUrl.value = state.serverUrl || 'https://carzo.site/api';
  els.connectorToken.value = state.connectorToken || '';
  els.marketplace.value = state.marketplace || 'mobile_de';
}

async function saveToken() {
  const serverUrl = cleanApiUrl(els.serverUrl.value);
  const connectorToken = els.connectorToken.value.trim();
  const marketplace = els.marketplace.value;
  if (!connectorToken.startsWith('carzo_dc_')) {
    setStatus(els.tokenStatus, 'Вставьте одноразовый код из Carzo. Он начинается с carzo_dc_', 'err');
    return;
  }
  els.saveToken.disabled = true;
  setStatus(els.tokenStatus, 'Проверяю связь с Carzo...', 'warn');
  try {
    await storageSet({ serverUrl, connectorToken, marketplace });
    const result = await postJson(`${serverUrl}/device-connectors/heartbeat`, {
      connectorToken,
      deviceName: 'Carzo Browser Connector',
      capabilities: ['platform_session_capture', 'cookies', 'local_storage']
    });
    setStatus(els.tokenStatus, `Связь есть. Устройство: ${result.connector?.status || 'active'}. Теперь выберите площадку, войдите обычным способом и нажмите «Синхронизировать».`, 'ok');
  } catch (error) {
    setStatus(els.tokenStatus, `Не удалось проверить код: ${humanizeError(error)}`, 'err');
  } finally {
    els.saveToken.disabled = false;
  }
}

async function openLogin() {
  const config = MARKETPLACES[els.marketplace.value];
  await storageSet({ marketplace: els.marketplace.value, serverUrl: cleanApiUrl(els.serverUrl.value), connectorToken: els.connectorToken.value.trim() });
  await tabsCreate({ url: config.loginUrl });
}

async function capture() {
  const serverUrl = cleanApiUrl(els.serverUrl.value);
  const connectorToken = els.connectorToken.value.trim();
  const marketplace = els.marketplace.value;
  const config = MARKETPLACES[marketplace];
  if (!connectorToken.startsWith('carzo_dc_')) {
    setStatus(els.syncStatus, 'Сначала вставьте код и нажмите проверку связи.', 'err');
    return;
  }

  els.capture.disabled = true;
  setStatus(els.syncStatus, `Собираю session cookies для ${config.label}...`, 'warn');
  try {
    await storageSet({ serverUrl, connectorToken, marketplace });
    const cookies = await collectCookies(config);
    const tabState = await collectActiveTabState(config);
    const marketplaceCookies = cookies.filter((cookie) => cookieDomainMatches(cookie, config));
    const authCookies = marketplaceCookies.filter(isAuthLikeCookie);
    const browserState = JSON.stringify({
      source: 'carzo-browser-extension',
      capturedAt: new Date().toISOString(),
      marketplace,
      cookies,
      activeTab: tabState
    });

    if (!cookies.length) {
      setStatus(els.syncStatus, `Cookies ${config.label} не найдены. Откройте вход через кнопку выше, войдите в аккаунт и нажмите «Синхронизировать» после входа. ${SOCIAL_LOGIN_HINT}`, 'err');
      return;
    }

    if (!marketplaceCookies.length) {
      setStatus(els.syncStatus, `В браузере есть cookies, но не для ${config.label}. Откройте правильную площадку через кнопку «Открыть вход», войдите и синхронизируйте снова.`, 'err');
      return;
    }

    if (!authCookies.length) {
      setStatus(els.syncStatus, `Пока вижу только технические cookies ${config.label}, а login/session cookies нет. ${SOCIAL_LOGIN_HINT}`, 'err');
      return;
    }

    const result = await postJson(`${serverUrl}/device-connectors/platform-sessions/${marketplace}/complete`, {
      connectorToken,
      cookies,
      browserState,
      userAgent: navigator.userAgent,
      platformUsername: tabState?.title || config.label
    });

    const status = result.session?.status || 'connected';
    setStatus(els.syncStatus, `Готово: ${config.label} подключён (${status}). Вернитесь в Carzo Settings и обновите страницу/статусы.`, 'ok');
  } catch (error) {
    setStatus(els.syncStatus, `Не подключилось: ${humanizeError(error, config)}`, 'err');
  } finally {
    els.capture.disabled = false;
  }
}

els.saveToken.addEventListener('click', saveToken);
els.openLogin.addEventListener('click', openLogin);
els.capture.addEventListener('click', capture);
els.marketplace.addEventListener('change', async () => {
  await storageSet({ marketplace: els.marketplace.value });
  const config = MARKETPLACES[els.marketplace.value];
  setStatus(els.syncStatus, `Выбрана площадка ${config.label}. Откройте вход, авторизуйтесь и нажмите синхронизацию.`, 'muted');
});

loadState().catch((error) => setStatus(els.tokenStatus, `Ошибка загрузки настроек: ${error.message}`, 'err'));
