# Carzo Connector — Browser Extension MVP

This is the first real connector for Carzo marketplace account sync.

## What it does

- Runs in the user's own Chrome/Edge browser.
- Accepts a one-time `carzo_dc_...` token from Carzo settings.
- Lets the user open Mobile.de, Kleinanzeigen, OLX.pl, AutoScout24, Otomoto, Sauto, Autovit, AutoTrack, Marktplaats and 2dehands login pages.
- After the user logs in normally, captures only cookies/session state for the selected marketplace.
- Sends the captured session to `https://carzo.site/api/device-connectors/platform-sessions/:marketplace/complete`.

## What it does not do

- It does not read or send marketplace passwords.
- It does not auto-submit login forms.
- It does not bypass CAPTCHA, anti-bot pages or marketplace security checks.
- It does not send sessions without the user clicking “Synchronize”.

## Install for testing

1. Download and unzip `carzo-connector-chrome-v0.1.0.zip`.
2. Open Chrome/Edge → Extensions → Developer mode.
3. Click “Load unpacked”.
4. Select the unzipped `browser-extension` folder.
5. In Carzo settings create a one-time connector code.
6. Paste the code into the extension popup, check connection, log into a marketplace and synchronize.

## User flow

1. Create a one-time code in Carzo → Settings → Device connector.
2. Open the Carzo Connector popup from the browser extension icon.
3. Paste the code into “Одноразовый код из Carzo” and check the connection.
4. Pick the marketplace in the popup and click “Открыть вход”.
5. Log in normally. Google, Apple and Facebook login redirects are expected.
6. After the marketplace shows the logged-in account, return to the popup and click “Синхронизировать”.

If the popup says it only sees technical cookies, the marketplace login is not finished yet or the browser has not returned from Google/Apple/Facebook to the marketplace domain.
